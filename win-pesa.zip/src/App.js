
import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", padding: 20 }}>
      <h1>Welcome to Win Pesa</h1>
      <p>This is your spin-to-win Firebase-powered app.</p>
    </div>
  );
}

export default App;
